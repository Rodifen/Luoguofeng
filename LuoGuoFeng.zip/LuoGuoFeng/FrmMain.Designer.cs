﻿namespace LuoGuoFeng
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSet = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.btnParameter = new System.Windows.Forms.Button();
            this.btnManual = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.panelBar = new System.Windows.Forms.Panel();
            this.btnUser = new System.Windows.Forms.Button();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Xcur_textBox = new System.Windows.Forms.TextBox();
            this.Ycur_textBox = new System.Windows.Forms.TextBox();
            this.Zcur_textBox = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lb_AlarmInfo = new System.Windows.Forms.Label();
            this.Acur_textBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Bcur_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.rich_Mess = new System.Windows.Forms.RichTextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lab_Now_model = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnSet);
            this.panel1.Controls.Add(this.btnLog);
            this.panel1.Controls.Add(this.btnParameter);
            this.panel1.Controls.Add(this.btnManual);
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Controls.Add(this.panelBar);
            this.panel1.Controls.Add(this.btnUser);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(20, 120);
            this.panel1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 760);
            this.panel1.TabIndex = 0;
            // 
            // btnSet
            // 
            this.btnSet.FlatAppearance.BorderSize = 0;
            this.btnSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSet.Image = ((System.Drawing.Image)(resources.GetObject("btnSet.Image")));
            this.btnSet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSet.Location = new System.Drawing.Point(34, 271);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(163, 66);
            this.btnSet.TabIndex = 1;
            this.btnSet.Text = "Set";
            this.btnSet.UseVisualStyleBackColor = true;
            this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // btnLog
            // 
            this.btnLog.FlatAppearance.BorderSize = 0;
            this.btnLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLog.Image = ((System.Drawing.Image)(resources.GetObject("btnLog.Image")));
            this.btnLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLog.Location = new System.Drawing.Point(35, 204);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(163, 66);
            this.btnLog.TabIndex = 1;
            this.btnLog.Text = "Log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btnParameter
            // 
            this.btnParameter.FlatAppearance.BorderSize = 0;
            this.btnParameter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParameter.Image = global::LuoGuoFeng.Properties.Resources.文件;
            this.btnParameter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnParameter.Location = new System.Drawing.Point(35, 71);
            this.btnParameter.Name = "btnParameter";
            this.btnParameter.Size = new System.Drawing.Size(163, 66);
            this.btnParameter.TabIndex = 1;
            this.btnParameter.Text = "   Parameters";
            this.btnParameter.UseVisualStyleBackColor = true;
            this.btnParameter.Click += new System.EventHandler(this.btnParameter_Click);
            // 
            // btnManual
            // 
            this.btnManual.FlatAppearance.BorderSize = 0;
            this.btnManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManual.Image = ((System.Drawing.Image)(resources.GetObject("btnManual.Image")));
            this.btnManual.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManual.Location = new System.Drawing.Point(35, 137);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(163, 66);
            this.btnManual.TabIndex = 1;
            this.btnManual.Text = "   Manual";
            this.btnManual.UseVisualStyleBackColor = true;
            this.btnManual.Click += new System.EventHandler(this.btnManual_Click);
            // 
            // btnHome
            // 
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(34, 3);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(163, 66);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "  Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panelBar
            // 
            this.panelBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panelBar.Location = new System.Drawing.Point(3, 3);
            this.panelBar.Name = "panelBar";
            this.panelBar.Size = new System.Drawing.Size(30, 66);
            this.panelBar.TabIndex = 0;
            // 
            // btnUser
            // 
            this.btnUser.FlatAppearance.BorderSize = 0;
            this.btnUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUser.Image = ((System.Drawing.Image)(resources.GetObject("btnUser.Image")));
            this.btnUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUser.Location = new System.Drawing.Point(41, 676);
            this.btnUser.Name = "btnUser";
            this.btnUser.Size = new System.Drawing.Size(163, 66);
            this.btnUser.TabIndex = 1;
            this.btnUser.Text = "  User";
            this.btnUser.UseVisualStyleBackColor = true;
            this.btnUser.Click += new System.EventHandler(this.btnUser_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.Location = new System.Drawing.Point(225, 120);
            this.panel_Main.MaximumSize = new System.Drawing.Size(940, 760);
            this.panel_Main.MinimumSize = new System.Drawing.Size(940, 760);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(940, 760);
            this.panel_Main.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1026, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // Xcur_textBox
            // 
            this.Xcur_textBox.BackColor = System.Drawing.Color.White;
            this.Xcur_textBox.Location = new System.Drawing.Point(72, 88);
            this.Xcur_textBox.Name = "Xcur_textBox";
            this.Xcur_textBox.ReadOnly = true;
            this.Xcur_textBox.Size = new System.Drawing.Size(127, 29);
            this.Xcur_textBox.TabIndex = 5;
            // 
            // Ycur_textBox
            // 
            this.Ycur_textBox.BackColor = System.Drawing.Color.White;
            this.Ycur_textBox.Location = new System.Drawing.Point(72, 130);
            this.Ycur_textBox.Name = "Ycur_textBox";
            this.Ycur_textBox.ReadOnly = true;
            this.Ycur_textBox.Size = new System.Drawing.Size(127, 29);
            this.Ycur_textBox.TabIndex = 5;
            // 
            // Zcur_textBox
            // 
            this.Zcur_textBox.BackColor = System.Drawing.Color.White;
            this.Zcur_textBox.Location = new System.Drawing.Point(72, 172);
            this.Zcur_textBox.Name = "Zcur_textBox";
            this.Zcur_textBox.ReadOnly = true;
            this.Zcur_textBox.Size = new System.Drawing.Size(127, 29);
            this.Zcur_textBox.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(13, 16);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(212, 29);
            this.textBox4.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 19);
            this.label1.TabIndex = 6;
            this.label1.Text = "X:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Y:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Z:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lb_AlarmInfo);
            this.panel4.Location = new System.Drawing.Point(260, 81);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(579, 33);
            this.panel4.TabIndex = 88;
            // 
            // lb_AlarmInfo
            // 
            this.lb_AlarmInfo.AutoSize = true;
            this.lb_AlarmInfo.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AlarmInfo.ForeColor = System.Drawing.Color.Red;
            this.lb_AlarmInfo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lb_AlarmInfo.Location = new System.Drawing.Point(3, 7);
            this.lb_AlarmInfo.Name = "lb_AlarmInfo";
            this.lb_AlarmInfo.Size = new System.Drawing.Size(74, 21);
            this.lb_AlarmInfo.TabIndex = 32;
            this.lb_AlarmInfo.Text = "报警信息";
            // 
            // Acur_textBox
            // 
            this.Acur_textBox.BackColor = System.Drawing.Color.White;
            this.Acur_textBox.Location = new System.Drawing.Point(72, 214);
            this.Acur_textBox.Name = "Acur_textBox";
            this.Acur_textBox.ReadOnly = true;
            this.Acur_textBox.Size = new System.Drawing.Size(127, 29);
            this.Acur_textBox.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "A:";
            // 
            // Bcur_textBox
            // 
            this.Bcur_textBox.BackColor = System.Drawing.Color.White;
            this.Bcur_textBox.Location = new System.Drawing.Point(72, 256);
            this.Bcur_textBox.Name = "Bcur_textBox";
            this.Bcur_textBox.ReadOnly = true;
            this.Bcur_textBox.Size = new System.Drawing.Size(127, 29);
            this.Bcur_textBox.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "B:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 19);
            this.label7.TabIndex = 6;
            this.label7.Text = "CurrPos:";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.rich_Mess);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.Bcur_textBox);
            this.panel2.Controls.Add(this.Xcur_textBox);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.Ycur_textBox);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.Zcur_textBox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.Acur_textBox);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1165, 120);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(255, 760);
            this.panel2.TabIndex = 89;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(143, 337);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(91, 29);
            this.textBox8.TabIndex = 5;
            // 
            // rich_Mess
            // 
            this.rich_Mess.Location = new System.Drawing.Point(13, 406);
            this.rich_Mess.Name = "rich_Mess";
            this.rich_Mess.Size = new System.Drawing.Size(212, 323);
            this.rich_Mess.TabIndex = 90;
            this.rich_Mess.Text = "";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(13, 339);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(91, 29);
            this.textBox7.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(139, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 19);
            this.label10.TabIndex = 6;
            this.label10.Text = "压力B:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 312);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 19);
            this.label9.TabIndex = 6;
            this.label9.Text = "压力A:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(958, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 19);
            this.label8.TabIndex = 4;
            this.label8.Text = "User:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::LuoGuoFeng.Properties.Resources.警告;
            this.pictureBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox3.Location = new System.Drawing.Point(220, 81);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(37, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 87;
            this.pictureBox3.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(958, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 19);
            this.label11.TabIndex = 4;
            this.label11.Text = "Model:";
            // 
            // lab_Now_model
            // 
            this.lab_Now_model.AutoSize = true;
            this.lab_Now_model.Location = new System.Drawing.Point(1030, 81);
            this.lab_Now_model.Name = "lab_Now_model";
            this.lab_Now_model.Size = new System.Drawing.Size(64, 19);
            this.lab_Now_model.TabIndex = 4;
            this.lab_Now_model.Text = "Model";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1440, 900);
            this.Controls.Add(this.panel_Main);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lab_Now_model);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "FrmMain";
            this.Padding = new System.Windows.Forms.Padding(20, 120, 20, 20);
            this.Text = "工控系统";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmMain_FormClosed);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.Panel panelBar;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnSet;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button btnManual;
        private System.Windows.Forms.Button btnUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lb_AlarmInfo;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnParameter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox rich_Mess;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.Label lab_Now_model;
        public System.Windows.Forms.TextBox Xcur_textBox;
        public System.Windows.Forms.TextBox Ycur_textBox;
        public System.Windows.Forms.TextBox Zcur_textBox;
        public System.Windows.Forms.TextBox Acur_textBox;
        public System.Windows.Forms.TextBox Bcur_textBox;
    }
}

