﻿namespace LuoGuoFeng
{
    partial class Axis_par
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.numericUpDown31 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.label82 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.numericUpDown30 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.numericUpDown29 = new System.Windows.Forms.NumericUpDown();
            this.label78 = new System.Windows.Forms.Label();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.label104 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDown28 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.numericUpDown27 = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.numericUpDown26 = new System.Windows.Forms.NumericUpDown();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.numericUpDown33 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown25 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown34 = new System.Windows.Forms.NumericUpDown();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.numericUpDown24 = new System.Windows.Forms.NumericUpDown();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.numericUpDown23 = new System.Windows.Forms.NumericUpDown();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.numericUpDown22 = new System.Windows.Forms.NumericUpDown();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.label70 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.numericUpDown35 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.numericUpDown32 = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.label56 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label117 = new System.Windows.Forms.Label();
            this.numericUpDown47 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown50 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown49 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown51 = new System.Windows.Forms.NumericUpDown();
            this.label134 = new System.Windows.Forms.Label();
            this.numericUpDown48 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown46 = new System.Windows.Forms.NumericUpDown();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.numericUpDown60 = new System.Windows.Forms.NumericUpDown();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.numericUpDown65 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown64 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown61 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown63 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown62 = new System.Windows.Forms.NumericUpDown();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label102 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.SaveAs_Cal_button = new System.Windows.Forms.Button();
            this.Open_Cal_Button = new System.Windows.Forms.Button();
            this.save_Cal_button = new System.Windows.Forms.Button();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown34)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown62)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(31, 38);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1160, 625);
            this.tabControl1.TabIndex = 44;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1152, 594);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "三轴";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox5);
            this.groupBox5.Controls.Add(this.numericUpDown31);
            this.groupBox5.Controls.Add(this.numericUpDown15);
            this.groupBox5.Controls.Add(this.label82);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.label105);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label81);
            this.groupBox5.Controls.Add(this.numericUpDown14);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.numericUpDown30);
            this.groupBox5.Controls.Add(this.numericUpDown13);
            this.groupBox5.Controls.Add(this.label80);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label79);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.numericUpDown12);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.numericUpDown11);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Location = new System.Drawing.Point(786, 59);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(318, 500);
            this.groupBox5.TabIndex = 43;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Z";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(125, 258);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(48, 21);
            this.checkBox5.TabIndex = 49;
            this.checkBox5.Text = "CW";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // numericUpDown31
            // 
            this.numericUpDown31.DecimalPlaces = 3;
            this.numericUpDown31.Location = new System.Drawing.Point(125, 221);
            this.numericUpDown31.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown31.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown31.Name = "numericUpDown31";
            this.numericUpDown31.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown31.TabIndex = 48;
            this.numericUpDown31.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.DecimalPlaces = 3;
            this.numericUpDown15.Location = new System.Drawing.Point(125, 188);
            this.numericUpDown15.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown15.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown15.TabIndex = 5;
            this.numericUpDown15.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(244, 225);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(17, 17);
            this.label82.TabIndex = 46;
            this.label82.Text = "s";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox15);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Controls.Add(this.textBox13);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Location = new System.Drawing.Point(30, 292);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(255, 186);
            this.groupBox6.TabIndex = 42;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "运动参数";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(150, 144);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(104, 27);
            this.textBox15.TabIndex = 10;
            this.textBox15.Text = "0";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(150, 114);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(104, 27);
            this.textBox14.TabIndex = 9;
            this.textBox14.Text = "0";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(150, 49);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(104, 27);
            this.textBox12.TabIndex = 7;
            this.textBox12.Text = "10000";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(150, 21);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(104, 27);
            this.textBox11.TabIndex = 6;
            this.textBox11.Text = "5000";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(150, 80);
            this.textBox13.Margin = new System.Windows.Forms.Padding(4);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(104, 27);
            this.textBox13.TabIndex = 8;
            this.textBox13.Text = "0.1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(15, 154);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(85, 17);
            this.label29.TabIndex = 0;
            this.label29.Text = "回零偏移:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(15, 123);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(85, 17);
            this.label30.TabIndex = 0;
            this.label30.Text = "回零模式:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(15, 93);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(136, 17);
            this.label31.TabIndex = 0;
            this.label31.Text = "回零加减速时间:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(15, 61);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 17);
            this.label32.TabIndex = 0;
            this.label32.Text = "回零高速:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(15, 31);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(85, 17);
            this.label33.TabIndex = 0;
            this.label33.Text = "回零低速:";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(42, 259);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(51, 17);
            this.label105.TabIndex = 47;
            this.label105.Text = "方向:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(244, 194);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(17, 17);
            this.label34.TabIndex = 0;
            this.label34.Text = "s";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(50, 222);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(77, 17);
            this.label81.TabIndex = 47;
            this.label81.Text = "S段时间:";
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.DecimalPlaces = 3;
            this.numericUpDown14.Location = new System.Drawing.Point(125, 157);
            this.numericUpDown14.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown14.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown14.TabIndex = 4;
            this.numericUpDown14.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(244, 160);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 17);
            this.label35.TabIndex = 0;
            this.label35.Text = "s";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(46, 190);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 17);
            this.label36.TabIndex = 0;
            this.label36.Text = "减速时间:";
            // 
            // numericUpDown30
            // 
            this.numericUpDown30.DecimalPlaces = 3;
            this.numericUpDown30.Location = new System.Drawing.Point(125, 123);
            this.numericUpDown30.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown30.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown30.Name = "numericUpDown30";
            this.numericUpDown30.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown30.TabIndex = 45;
            this.numericUpDown30.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown13
            // 
            this.numericUpDown13.DecimalPlaces = 3;
            this.numericUpDown13.Location = new System.Drawing.Point(125, 92);
            this.numericUpDown13.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown13.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown13.TabIndex = 3;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(247, 128);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(62, 17);
            this.label80.TabIndex = 43;
            this.label80.Text = "unit/s";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(46, 157);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(85, 17);
            this.label37.TabIndex = 0;
            this.label37.Text = "加速时间:";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(46, 126);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(85, 17);
            this.label79.TabIndex = 44;
            this.label79.Text = "运行速度:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(244, 95);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(62, 17);
            this.label38.TabIndex = 0;
            this.label38.Text = "unit/s";
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.DecimalPlaces = 3;
            this.numericUpDown12.Location = new System.Drawing.Point(125, 58);
            this.numericUpDown12.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown12.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown12.TabIndex = 2;
            this.numericUpDown12.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(46, 95);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(85, 17);
            this.label39.TabIndex = 0;
            this.label39.Text = "起始速度:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(240, 60);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(98, 17);
            this.label40.TabIndex = 0;
            this.label40.Text = "pulse/unit";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(46, 61);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 17);
            this.label41.TabIndex = 0;
            this.label41.Text = "脉冲当量:";
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Location = new System.Drawing.Point(125, 25);
            this.numericUpDown11.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown11.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown11.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(46, 30);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(85, 17);
            this.label42.TabIndex = 0;
            this.label42.Text = "电机轴号:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.numericUpDown29);
            this.groupBox3.Controls.Add(this.label78);
            this.groupBox3.Controls.Add(this.numericUpDown10);
            this.groupBox3.Controls.Add(this.label104);
            this.groupBox3.Controls.Add(this.label77);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.numericUpDown28);
            this.groupBox3.Controls.Add(this.numericUpDown9);
            this.groupBox3.Controls.Add(this.label76);
            this.groupBox3.Controls.Add(this.label75);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.numericUpDown8);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.numericUpDown7);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.numericUpDown6);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Location = new System.Drawing.Point(440, 59);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(314, 500);
            this.groupBox3.TabIndex = 43;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Y";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(126, 259);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(48, 21);
            this.checkBox3.TabIndex = 49;
            this.checkBox3.Text = "CW";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // numericUpDown29
            // 
            this.numericUpDown29.DecimalPlaces = 3;
            this.numericUpDown29.Location = new System.Drawing.Point(126, 225);
            this.numericUpDown29.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown29.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown29.Name = "numericUpDown29";
            this.numericUpDown29.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown29.TabIndex = 48;
            this.numericUpDown29.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(244, 230);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(17, 17);
            this.label78.TabIndex = 46;
            this.label78.Text = "s";
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.DecimalPlaces = 3;
            this.numericUpDown10.Location = new System.Drawing.Point(126, 191);
            this.numericUpDown10.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown10.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown10.TabIndex = 5;
            this.numericUpDown10.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(35, 259);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(51, 17);
            this.label104.TabIndex = 47;
            this.label104.Text = "方向:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(46, 228);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(77, 17);
            this.label77.TabIndex = 47;
            this.label77.Text = "S段时间:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.textBox8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Location = new System.Drawing.Point(31, 292);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(255, 186);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "运动参数";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(150, 150);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(104, 27);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "0";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(150, 120);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(104, 27);
            this.textBox9.TabIndex = 9;
            this.textBox9.Text = "0";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(150, 55);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(104, 27);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "10000";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(150, 27);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(104, 27);
            this.textBox6.TabIndex = 6;
            this.textBox6.Text = "5000";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(150, 86);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(104, 27);
            this.textBox8.TabIndex = 8;
            this.textBox8.Text = "0.1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 154);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "回零偏移:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 123);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "回零模式:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 93);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(136, 17);
            this.label13.TabIndex = 0;
            this.label13.Text = "回零加减速时间:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 61);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "回零高速:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 31);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "回零低速:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(244, 161);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "s";
            // 
            // numericUpDown28
            // 
            this.numericUpDown28.DecimalPlaces = 3;
            this.numericUpDown28.Location = new System.Drawing.Point(126, 126);
            this.numericUpDown28.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown28.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown28.Name = "numericUpDown28";
            this.numericUpDown28.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown28.TabIndex = 45;
            this.numericUpDown28.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.DecimalPlaces = 3;
            this.numericUpDown9.Location = new System.Drawing.Point(126, 157);
            this.numericUpDown9.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown9.TabIndex = 4;
            this.numericUpDown9.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(248, 128);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(62, 17);
            this.label76.TabIndex = 43;
            this.label76.Text = "unit/s";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(46, 128);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(85, 17);
            this.label75.TabIndex = 44;
            this.label75.Text = "运行速度:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(244, 196);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(17, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "s";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(46, 195);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(85, 17);
            this.label18.TabIndex = 0;
            this.label18.Text = "减速时间:";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.DecimalPlaces = 3;
            this.numericUpDown8.Location = new System.Drawing.Point(126, 89);
            this.numericUpDown8.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown8.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(46, 161);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(85, 17);
            this.label23.TabIndex = 0;
            this.label23.Text = "加速时间:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(244, 93);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(62, 17);
            this.label24.TabIndex = 0;
            this.label24.Text = "unit/s";
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.DecimalPlaces = 3;
            this.numericUpDown7.Location = new System.Drawing.Point(126, 58);
            this.numericUpDown7.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown7.TabIndex = 2;
            this.numericUpDown7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(46, 94);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(85, 17);
            this.label25.TabIndex = 0;
            this.label25.Text = "起始速度:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(244, 59);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(98, 17);
            this.label26.TabIndex = 0;
            this.label26.Text = "pulse/unit";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(46, 61);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 17);
            this.label27.TabIndex = 0;
            this.label27.Text = "脉冲当量:";
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(126, 24);
            this.numericUpDown6.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown6.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(46, 27);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 17);
            this.label28.TabIndex = 0;
            this.label28.Text = "电机轴号:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.numericUpDown27);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.label103);
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.numericUpDown26);
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.label72);
            this.groupBox1.Controls.Add(this.numericUpDown5);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Location = new System.Drawing.Point(57, 59);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(316, 500);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "X";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(118, 259);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 21);
            this.checkBox1.TabIndex = 49;
            this.checkBox1.Text = "CW";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // numericUpDown27
            // 
            this.numericUpDown27.DecimalPlaces = 3;
            this.numericUpDown27.Location = new System.Drawing.Point(118, 228);
            this.numericUpDown27.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown27.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown27.Name = "numericUpDown27";
            this.numericUpDown27.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown27.TabIndex = 48;
            this.numericUpDown27.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(238, 230);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(17, 17);
            this.label73.TabIndex = 46;
            this.label73.Text = "s";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(40, 259);
            this.label103.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(51, 17);
            this.label103.TabIndex = 47;
            this.label103.Text = "方向:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(40, 230);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(77, 17);
            this.label74.TabIndex = 47;
            this.label74.Text = "S段时间:";
            // 
            // numericUpDown26
            // 
            this.numericUpDown26.DecimalPlaces = 3;
            this.numericUpDown26.Location = new System.Drawing.Point(118, 127);
            this.numericUpDown26.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown26.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown26.Name = "numericUpDown26";
            this.numericUpDown26.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown26.TabIndex = 45;
            this.numericUpDown26.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(242, 129);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(62, 17);
            this.label71.TabIndex = 43;
            this.label71.Text = "unit/s";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(40, 129);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(85, 17);
            this.label72.TabIndex = 44;
            this.label72.Text = "运行速度:";
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.DecimalPlaces = 3;
            this.numericUpDown5.Location = new System.Drawing.Point(118, 194);
            this.numericUpDown5.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown5.TabIndex = 5;
            this.numericUpDown5.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(28, 292);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(255, 186);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "运动参数";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(151, 150);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(104, 27);
            this.textBox5.TabIndex = 10;
            this.textBox5.Text = "0";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(151, 120);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(104, 27);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(151, 55);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(104, 27);
            this.textBox2.TabIndex = 7;
            this.textBox2.Text = "10000";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(151, 27);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(104, 27);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "5000";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(151, 86);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(104, 27);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "0.1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 154);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "回零偏移:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 123);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "回零模式:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 93);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "回零加减速时间:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 61);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "回零高速:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 31);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "回零低速:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(238, 197);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "s";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 3;
            this.numericUpDown4.Location = new System.Drawing.Point(118, 160);
            this.numericUpDown4.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown4.TabIndex = 4;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(238, 166);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "s";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 197);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "减速时间:";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DecimalPlaces = 3;
            this.numericUpDown3.Location = new System.Drawing.Point(118, 92);
            this.numericUpDown3.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown3.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 163);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "加速时间:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(238, 95);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "unit/s";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 3;
            this.numericUpDown2.Location = new System.Drawing.Point(118, 59);
            this.numericUpDown2.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown2.TabIndex = 2;
            this.numericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(40, 95);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(85, 17);
            this.label19.TabIndex = 0;
            this.label19.Text = "起始速度:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(238, 61);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 17);
            this.label20.TabIndex = 0;
            this.label20.Text = "pulse/unit";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(40, 64);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 17);
            this.label21.TabIndex = 0;
            this.label21.Text = "脉冲当量:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(118, 26);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown1.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 30);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 17);
            this.label22.TabIndex = 0;
            this.label22.Text = "电机轴号:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1152, 594);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "胶泵";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.numericUpDown33);
            this.groupBox9.Controls.Add(this.numericUpDown25);
            this.groupBox9.Controls.Add(this.numericUpDown34);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.label85);
            this.groupBox9.Controls.Add(this.label86);
            this.groupBox9.Controls.Add(this.label62);
            this.groupBox9.Controls.Add(this.numericUpDown24);
            this.groupBox9.Controls.Add(this.label63);
            this.groupBox9.Controls.Add(this.label64);
            this.groupBox9.Controls.Add(this.label106);
            this.groupBox9.Controls.Add(this.numericUpDown23);
            this.groupBox9.Controls.Add(this.label65);
            this.groupBox9.Controls.Add(this.label66);
            this.groupBox9.Controls.Add(this.numericUpDown22);
            this.groupBox9.Controls.Add(this.label67);
            this.groupBox9.Controls.Add(this.label68);
            this.groupBox9.Controls.Add(this.label69);
            this.groupBox9.Controls.Add(this.numericUpDown21);
            this.groupBox9.Controls.Add(this.label70);
            this.groupBox9.Location = new System.Drawing.Point(710, 68);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(321, 500);
            this.groupBox9.TabIndex = 46;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "B";
            // 
            // numericUpDown33
            // 
            this.numericUpDown33.DecimalPlaces = 3;
            this.numericUpDown33.Location = new System.Drawing.Point(116, 225);
            this.numericUpDown33.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown33.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown33.Name = "numericUpDown33";
            this.numericUpDown33.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown33.TabIndex = 48;
            this.numericUpDown33.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // numericUpDown25
            // 
            this.numericUpDown25.Location = new System.Drawing.Point(116, 195);
            this.numericUpDown25.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown25.Name = "numericUpDown25";
            this.numericUpDown25.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown25.TabIndex = 5;
            this.numericUpDown25.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown34
            // 
            this.numericUpDown34.DecimalPlaces = 3;
            this.numericUpDown34.Location = new System.Drawing.Point(116, 132);
            this.numericUpDown34.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown34.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown34.Name = "numericUpDown34";
            this.numericUpDown34.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown34.TabIndex = 45;
            this.numericUpDown34.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox25);
            this.groupBox10.Controls.Add(this.textBox24);
            this.groupBox10.Controls.Add(this.textBox22);
            this.groupBox10.Controls.Add(this.textBox21);
            this.groupBox10.Controls.Add(this.textBox23);
            this.groupBox10.Controls.Add(this.label57);
            this.groupBox10.Controls.Add(this.label58);
            this.groupBox10.Controls.Add(this.label59);
            this.groupBox10.Controls.Add(this.label60);
            this.groupBox10.Controls.Add(this.label61);
            this.groupBox10.Location = new System.Drawing.Point(40, 307);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(255, 186);
            this.groupBox10.TabIndex = 42;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "运动参数";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(130, 150);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(104, 27);
            this.textBox25.TabIndex = 10;
            this.textBox25.Text = "0";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(130, 120);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(104, 27);
            this.textBox24.TabIndex = 9;
            this.textBox24.Text = "28";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(130, 55);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(104, 27);
            this.textBox22.TabIndex = 7;
            this.textBox22.Text = "10000";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(130, 27);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(104, 27);
            this.textBox21.TabIndex = 6;
            this.textBox21.Text = "5000";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(130, 86);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(104, 27);
            this.textBox23.TabIndex = 8;
            this.textBox23.Text = "0.1";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(15, 154);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(85, 17);
            this.label57.TabIndex = 0;
            this.label57.Text = "回零偏移:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(15, 123);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(85, 17);
            this.label58.TabIndex = 0;
            this.label58.Text = "回零模式:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(15, 93);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(136, 17);
            this.label59.TabIndex = 0;
            this.label59.Text = "回零加减速时间:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(15, 61);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(85, 17);
            this.label60.TabIndex = 0;
            this.label60.Text = "回零高速:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(15, 31);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(85, 17);
            this.label61.TabIndex = 0;
            this.label61.Text = "回零低速:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(37, 230);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(77, 17);
            this.label85.TabIndex = 47;
            this.label85.Text = "S段时间:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(235, 197);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(17, 17);
            this.label86.TabIndex = 0;
            this.label86.Text = "s";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(235, 166);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(17, 17);
            this.label62.TabIndex = 0;
            this.label62.Text = "s";
            // 
            // numericUpDown24
            // 
            this.numericUpDown24.DecimalPlaces = 3;
            this.numericUpDown24.Location = new System.Drawing.Point(116, 163);
            this.numericUpDown24.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown24.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown24.Name = "numericUpDown24";
            this.numericUpDown24.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown24.TabIndex = 4;
            this.numericUpDown24.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(235, 135);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(17, 17);
            this.label63.TabIndex = 0;
            this.label63.Text = "s";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(37, 197);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(85, 17);
            this.label64.TabIndex = 0;
            this.label64.Text = "减速时间:";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(37, 136);
            this.label106.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(85, 17);
            this.label106.TabIndex = 44;
            this.label106.Text = "运行速度:";
            // 
            // numericUpDown23
            // 
            this.numericUpDown23.DecimalPlaces = 3;
            this.numericUpDown23.Location = new System.Drawing.Point(116, 101);
            this.numericUpDown23.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown23.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown23.Name = "numericUpDown23";
            this.numericUpDown23.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown23.TabIndex = 3;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(37, 167);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(85, 17);
            this.label65.TabIndex = 0;
            this.label65.Text = "加速时间:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(235, 103);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(62, 17);
            this.label66.TabIndex = 0;
            this.label66.Text = "unit/s";
            // 
            // numericUpDown22
            // 
            this.numericUpDown22.DecimalPlaces = 3;
            this.numericUpDown22.Location = new System.Drawing.Point(116, 69);
            this.numericUpDown22.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown22.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown22.Name = "numericUpDown22";
            this.numericUpDown22.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown22.TabIndex = 2;
            this.numericUpDown22.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(37, 105);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(85, 17);
            this.label67.TabIndex = 0;
            this.label67.Text = "起始速度:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(235, 72);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(98, 17);
            this.label68.TabIndex = 0;
            this.label68.Text = "pulse/unit";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(37, 75);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(85, 17);
            this.label69.TabIndex = 0;
            this.label69.Text = "脉冲当量:";
            // 
            // numericUpDown21
            // 
            this.numericUpDown21.Location = new System.Drawing.Point(116, 38);
            this.numericUpDown21.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown21.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown21.TabIndex = 1;
            this.numericUpDown21.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(37, 42);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(85, 17);
            this.label70.TabIndex = 0;
            this.label70.Text = "电机轴号:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.numericUpDown35);
            this.groupBox7.Controls.Add(this.numericUpDown20);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.label107);
            this.groupBox7.Controls.Add(this.numericUpDown19);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.numericUpDown18);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.numericUpDown32);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.label83);
            this.groupBox7.Controls.Add(this.numericUpDown17);
            this.groupBox7.Controls.Add(this.label84);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.label54);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.numericUpDown16);
            this.groupBox7.Controls.Add(this.label56);
            this.groupBox7.Location = new System.Drawing.Point(280, 68);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(330, 500);
            this.groupBox7.TabIndex = 46;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "A";
            // 
            // numericUpDown35
            // 
            this.numericUpDown35.DecimalPlaces = 3;
            this.numericUpDown35.Location = new System.Drawing.Point(116, 230);
            this.numericUpDown35.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown35.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown35.Name = "numericUpDown35";
            this.numericUpDown35.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown35.TabIndex = 48;
            this.numericUpDown35.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.DecimalPlaces = 3;
            this.numericUpDown20.Location = new System.Drawing.Point(116, 195);
            this.numericUpDown20.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown20.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown20.TabIndex = 5;
            this.numericUpDown20.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox20);
            this.groupBox8.Controls.Add(this.textBox19);
            this.groupBox8.Controls.Add(this.textBox17);
            this.groupBox8.Controls.Add(this.textBox16);
            this.groupBox8.Controls.Add(this.textBox18);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Location = new System.Drawing.Point(26, 297);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(255, 186);
            this.groupBox8.TabIndex = 42;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "运动参数";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(130, 150);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(104, 27);
            this.textBox20.TabIndex = 10;
            this.textBox20.Text = "0";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(130, 120);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(104, 27);
            this.textBox19.TabIndex = 9;
            this.textBox19.Text = "28";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(130, 55);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(104, 27);
            this.textBox17.TabIndex = 7;
            this.textBox17.Text = "10000";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(130, 27);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(104, 27);
            this.textBox16.TabIndex = 6;
            this.textBox16.Text = "5000";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(130, 86);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(104, 27);
            this.textBox18.TabIndex = 8;
            this.textBox18.Text = "0.1";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(15, 154);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(85, 17);
            this.label43.TabIndex = 0;
            this.label43.Text = "回零偏移:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(15, 123);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(85, 17);
            this.label44.TabIndex = 0;
            this.label44.Text = "回零模式:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(15, 93);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(136, 17);
            this.label45.TabIndex = 0;
            this.label45.Text = "回零加减速时间:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 61);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(85, 17);
            this.label46.TabIndex = 0;
            this.label46.Text = "回零高速:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(15, 31);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(85, 17);
            this.label47.TabIndex = 0;
            this.label47.Text = "回零低速:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(235, 201);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(17, 17);
            this.label48.TabIndex = 0;
            this.label48.Text = "s";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(37, 230);
            this.label107.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(77, 17);
            this.label107.TabIndex = 47;
            this.label107.Text = "S段时间:";
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.DecimalPlaces = 3;
            this.numericUpDown19.Location = new System.Drawing.Point(116, 163);
            this.numericUpDown19.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown19.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown19.TabIndex = 4;
            this.numericUpDown19.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(235, 170);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(17, 17);
            this.label49.TabIndex = 0;
            this.label49.Text = "s";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(37, 197);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(85, 17);
            this.label50.TabIndex = 0;
            this.label50.Text = "减速时间:";
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.DecimalPlaces = 3;
            this.numericUpDown18.Location = new System.Drawing.Point(116, 101);
            this.numericUpDown18.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown18.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown18.TabIndex = 3;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(37, 167);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(85, 17);
            this.label51.TabIndex = 0;
            this.label51.Text = "加速时间:";
            // 
            // numericUpDown32
            // 
            this.numericUpDown32.DecimalPlaces = 3;
            this.numericUpDown32.Location = new System.Drawing.Point(116, 132);
            this.numericUpDown32.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown32.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown32.Name = "numericUpDown32";
            this.numericUpDown32.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown32.TabIndex = 45;
            this.numericUpDown32.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(235, 105);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(62, 17);
            this.label52.TabIndex = 0;
            this.label52.Text = "unit/s";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(37, 136);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(85, 17);
            this.label83.TabIndex = 44;
            this.label83.Text = "运行速度:";
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.DecimalPlaces = 3;
            this.numericUpDown17.Location = new System.Drawing.Point(116, 69);
            this.numericUpDown17.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown17.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown17.TabIndex = 2;
            this.numericUpDown17.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(238, 137);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(62, 17);
            this.label84.TabIndex = 43;
            this.label84.Text = "unit/s";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(37, 105);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(85, 17);
            this.label53.TabIndex = 0;
            this.label53.Text = "起始速度:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(235, 72);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(98, 17);
            this.label54.TabIndex = 0;
            this.label54.Text = "pulse/unit";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(37, 75);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(85, 17);
            this.label55.TabIndex = 0;
            this.label55.Text = "脉冲当量:";
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.Location = new System.Drawing.Point(116, 38);
            this.numericUpDown16.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown16.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown16.TabIndex = 1;
            this.numericUpDown16.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(37, 42);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(85, 17);
            this.label56.TabIndex = 0;
            this.label56.Text = "电机轴号:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Controls.Add(this.comboBox3);
            this.tabPage4.Controls.Add(this.comboBox2);
            this.tabPage4.Controls.Add(this.comboBox1);
            this.tabPage4.Controls.Add(this.label124);
            this.tabPage4.Controls.Add(this.label128);
            this.tabPage4.Controls.Add(this.label125);
            this.tabPage4.Controls.Add(this.label108);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1152, 594);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "胶泵参数";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label110);
            this.panel1.Controls.Add(this.label131);
            this.panel1.Controls.Add(this.label109);
            this.panel1.Controls.Add(this.label130);
            this.panel1.Controls.Add(this.label118);
            this.panel1.Controls.Add(this.label115);
            this.panel1.Controls.Add(this.label129);
            this.panel1.Controls.Add(this.numericUpDown60);
            this.panel1.Controls.Add(this.label114);
            this.panel1.Controls.Add(this.label113);
            this.panel1.Controls.Add(this.label127);
            this.panel1.Controls.Add(this.label112);
            this.panel1.Controls.Add(this.numericUpDown65);
            this.panel1.Controls.Add(this.numericUpDown64);
            this.panel1.Controls.Add(this.numericUpDown61);
            this.panel1.Controls.Add(this.numericUpDown63);
            this.panel1.Controls.Add(this.numericUpDown62);
            this.panel1.Location = new System.Drawing.Point(168, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(629, 406);
            this.panel1.TabIndex = 50;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label117);
            this.panel2.Controls.Add(this.numericUpDown47);
            this.panel2.Controls.Add(this.numericUpDown50);
            this.panel2.Controls.Add(this.numericUpDown49);
            this.panel2.Controls.Add(this.numericUpDown51);
            this.panel2.Controls.Add(this.label134);
            this.panel2.Controls.Add(this.numericUpDown48);
            this.panel2.Controls.Add(this.numericUpDown46);
            this.panel2.Controls.Add(this.label132);
            this.panel2.Controls.Add(this.label133);
            this.panel2.Controls.Add(this.label111);
            this.panel2.Location = new System.Drawing.Point(356, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(203, 372);
            this.panel2.TabIndex = 49;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(40, 38);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(34, 17);
            this.label117.TabIndex = 0;
            this.label117.Text = "B泵";
            // 
            // numericUpDown47
            // 
            this.numericUpDown47.DecimalPlaces = 3;
            this.numericUpDown47.Location = new System.Drawing.Point(7, 125);
            this.numericUpDown47.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown47.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown47.Name = "numericUpDown47";
            this.numericUpDown47.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown47.TabIndex = 4;
            this.numericUpDown47.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown50
            // 
            this.numericUpDown50.DecimalPlaces = 3;
            this.numericUpDown50.Location = new System.Drawing.Point(7, 260);
            this.numericUpDown50.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown50.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown50.Name = "numericUpDown50";
            this.numericUpDown50.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown50.TabIndex = 4;
            this.numericUpDown50.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown49
            // 
            this.numericUpDown49.DecimalPlaces = 3;
            this.numericUpDown49.Location = new System.Drawing.Point(7, 215);
            this.numericUpDown49.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown49.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown49.Name = "numericUpDown49";
            this.numericUpDown49.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown49.TabIndex = 4;
            this.numericUpDown49.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown51
            // 
            this.numericUpDown51.DecimalPlaces = 3;
            this.numericUpDown51.Location = new System.Drawing.Point(7, 305);
            this.numericUpDown51.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown51.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown51.Name = "numericUpDown51";
            this.numericUpDown51.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown51.TabIndex = 4;
            this.numericUpDown51.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(126, 214);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(44, 17);
            this.label134.TabIndex = 0;
            this.label134.Text = "ml/g";
            // 
            // numericUpDown48
            // 
            this.numericUpDown48.DecimalPlaces = 3;
            this.numericUpDown48.Location = new System.Drawing.Point(7, 170);
            this.numericUpDown48.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown48.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown48.Name = "numericUpDown48";
            this.numericUpDown48.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown48.TabIndex = 4;
            this.numericUpDown48.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown46
            // 
            this.numericUpDown46.DecimalPlaces = 3;
            this.numericUpDown46.Location = new System.Drawing.Point(6, 80);
            this.numericUpDown46.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown46.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown46.Name = "numericUpDown46";
            this.numericUpDown46.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown46.TabIndex = 4;
            this.numericUpDown46.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(126, 134);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(26, 17);
            this.label132.TabIndex = 0;
            this.label132.Text = "mm";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(126, 85);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(26, 17);
            this.label133.TabIndex = 0;
            this.label133.Text = "mm";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(126, 262);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(26, 17);
            this.label111.TabIndex = 0;
            this.label111.Text = "mm";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(88, 308);
            this.label110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(51, 17);
            this.label110.TabIndex = 1;
            this.label110.Text = "比例:";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(86, 260);
            this.label131.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(51, 17);
            this.label131.TabIndex = 1;
            this.label131.Text = "泵径:";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(86, 84);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(76, 17);
            this.label109.TabIndex = 0;
            this.label109.Text = "有效行程";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(86, 216);
            this.label130.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(59, 17);
            this.label130.TabIndex = 1;
            this.label130.Text = "密度：";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(316, 223);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(44, 17);
            this.label118.TabIndex = 0;
            this.label118.Text = "ml/g";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(242, 38);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(34, 17);
            this.label115.TabIndex = 0;
            this.label115.Text = "A泵";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(86, 172);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(59, 17);
            this.label129.TabIndex = 0;
            this.label129.Text = "减速比";
            // 
            // numericUpDown60
            // 
            this.numericUpDown60.DecimalPlaces = 3;
            this.numericUpDown60.Location = new System.Drawing.Point(197, 80);
            this.numericUpDown60.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown60.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown60.Name = "numericUpDown60";
            this.numericUpDown60.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown60.TabIndex = 4;
            this.numericUpDown60.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(316, 143);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(26, 17);
            this.label114.TabIndex = 0;
            this.label114.Text = "mm";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(316, 94);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(26, 17);
            this.label113.TabIndex = 0;
            this.label113.Text = "mm";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(86, 128);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(42, 17);
            this.label127.TabIndex = 0;
            this.label127.Text = "螺距";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(316, 271);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(26, 17);
            this.label112.TabIndex = 0;
            this.label112.Text = "mm";
            // 
            // numericUpDown65
            // 
            this.numericUpDown65.DecimalPlaces = 3;
            this.numericUpDown65.Location = new System.Drawing.Point(197, 306);
            this.numericUpDown65.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown65.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown65.Name = "numericUpDown65";
            this.numericUpDown65.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown65.TabIndex = 4;
            this.numericUpDown65.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown64
            // 
            this.numericUpDown64.DecimalPlaces = 3;
            this.numericUpDown64.Location = new System.Drawing.Point(197, 260);
            this.numericUpDown64.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown64.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown64.Name = "numericUpDown64";
            this.numericUpDown64.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown64.TabIndex = 4;
            this.numericUpDown64.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown61
            // 
            this.numericUpDown61.DecimalPlaces = 3;
            this.numericUpDown61.Location = new System.Drawing.Point(197, 128);
            this.numericUpDown61.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown61.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown61.Name = "numericUpDown61";
            this.numericUpDown61.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown61.TabIndex = 4;
            this.numericUpDown61.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown63
            // 
            this.numericUpDown63.DecimalPlaces = 3;
            this.numericUpDown63.Location = new System.Drawing.Point(197, 216);
            this.numericUpDown63.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown63.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown63.Name = "numericUpDown63";
            this.numericUpDown63.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown63.TabIndex = 4;
            this.numericUpDown63.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // numericUpDown62
            // 
            this.numericUpDown62.DecimalPlaces = 3;
            this.numericUpDown62.Location = new System.Drawing.Point(197, 172);
            this.numericUpDown62.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown62.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.numericUpDown62.Name = "numericUpDown62";
            this.numericUpDown62.Size = new System.Drawing.Size(112, 27);
            this.numericUpDown62.TabIndex = 4;
            this.numericUpDown62.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // comboBox3
            // 
            this.comboBox3.AutoCompleteCustomSource.AddRange(new string[] {
            "Single",
            "Blend"});
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Quality",
            "Time"});
            this.comboBox3.Location = new System.Drawing.Point(882, 32);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(109, 25);
            this.comboBox3.TabIndex = 47;
            this.comboBox3.Text = "Quality";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteCustomSource.AddRange(new string[] {
            "Single",
            "Blend"});
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Single",
            "Double"});
            this.comboBox2.Location = new System.Drawing.Point(621, 32);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(109, 25);
            this.comboBox2.TabIndex = 47;
            this.comboBox2.Text = "Single";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Gear_pump",
            "Volumetric_piston"});
            this.comboBox1.Location = new System.Drawing.Point(168, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(192, 25);
            this.comboBox1.TabIndex = 47;
            this.comboBox1.Text = "Volumetric_piston";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(289, 40);
            this.label124.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(0, 17);
            this.label124.TabIndex = 0;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(793, 39);
            this.label128.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(71, 17);
            this.label128.TabIndex = 0;
            this.label128.Text = "fashion";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(470, 34);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(143, 17);
            this.label125.TabIndex = 0;
            this.label125.Text = "Number of axes:";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(74, 39);
            this.label108.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(106, 17);
            this.label108.TabIndex = 0;
            this.label108.Text = "Pump type：";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label102);
            this.tabPage3.Controls.Add(this.label94);
            this.tabPage3.Controls.Add(this.label101);
            this.tabPage3.Controls.Add(this.label90);
            this.tabPage3.Controls.Add(this.label100);
            this.tabPage3.Controls.Add(this.label93);
            this.tabPage3.Controls.Add(this.label99);
            this.tabPage3.Controls.Add(this.label89);
            this.tabPage3.Controls.Add(this.label98);
            this.tabPage3.Controls.Add(this.label92);
            this.tabPage3.Controls.Add(this.label97);
            this.tabPage3.Controls.Add(this.label88);
            this.tabPage3.Controls.Add(this.label96);
            this.tabPage3.Controls.Add(this.label91);
            this.tabPage3.Controls.Add(this.label95);
            this.tabPage3.Controls.Add(this.label87);
            this.tabPage3.Controls.Add(this.textBox42);
            this.tabPage3.Controls.Add(this.textBox41);
            this.tabPage3.Controls.Add(this.textBox34);
            this.tabPage3.Controls.Add(this.textBox40);
            this.tabPage3.Controls.Add(this.textBox30);
            this.tabPage3.Controls.Add(this.textBox39);
            this.tabPage3.Controls.Add(this.textBox33);
            this.tabPage3.Controls.Add(this.textBox38);
            this.tabPage3.Controls.Add(this.textBox32);
            this.tabPage3.Controls.Add(this.textBox37);
            this.tabPage3.Controls.Add(this.textBox29);
            this.tabPage3.Controls.Add(this.textBox36);
            this.tabPage3.Controls.Add(this.textBox31);
            this.tabPage3.Controls.Add(this.textBox35);
            this.tabPage3.Controls.Add(this.textBox28);
            this.tabPage3.Controls.Add(this.textBox27);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1152, 594);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "IO 名";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(256, 439);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(51, 17);
            this.label102.TabIndex = 1;
            this.label102.Text = "输入7";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(584, 439);
            this.label94.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(51, 17);
            this.label94.TabIndex = 1;
            this.label94.Text = "输出7";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(256, 242);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(51, 17);
            this.label101.TabIndex = 1;
            this.label101.Text = "输入3";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(584, 242);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(51, 17);
            this.label90.TabIndex = 1;
            this.label90.Text = "输出3";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(256, 390);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(51, 17);
            this.label100.TabIndex = 1;
            this.label100.Text = "输入6";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(584, 390);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(51, 17);
            this.label93.TabIndex = 1;
            this.label93.Text = "输出6";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(256, 194);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(51, 17);
            this.label99.TabIndex = 1;
            this.label99.Text = "输入2";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(584, 194);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(51, 17);
            this.label89.TabIndex = 1;
            this.label89.Text = "输出2";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(256, 341);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(51, 17);
            this.label98.TabIndex = 1;
            this.label98.Text = "输入5";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(584, 341);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(51, 17);
            this.label92.TabIndex = 1;
            this.label92.Text = "输出5";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(256, 144);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(51, 17);
            this.label97.TabIndex = 1;
            this.label97.Text = "输入1";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(584, 144);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(51, 17);
            this.label88.TabIndex = 1;
            this.label88.Text = "输出1";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(256, 293);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(51, 17);
            this.label96.TabIndex = 1;
            this.label96.Text = "输入4";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(584, 293);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(51, 17);
            this.label91.TabIndex = 1;
            this.label91.Text = "输出4";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(256, 95);
            this.label95.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(51, 17);
            this.label95.TabIndex = 1;
            this.label95.Text = "输入0";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(584, 95);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(51, 17);
            this.label87.TabIndex = 1;
            this.label87.Text = "输出0";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(305, 439);
            this.textBox42.Margin = new System.Windows.Forms.Padding(4);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(144, 27);
            this.textBox42.TabIndex = 0;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(309, 390);
            this.textBox41.Margin = new System.Windows.Forms.Padding(4);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(144, 27);
            this.textBox41.TabIndex = 0;
            this.textBox41.TextChanged += new System.EventHandler(this.textBox41_TextChanged);
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(634, 439);
            this.textBox34.Margin = new System.Windows.Forms.Padding(4);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(144, 27);
            this.textBox34.TabIndex = 0;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(309, 341);
            this.textBox40.Margin = new System.Windows.Forms.Padding(4);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(144, 27);
            this.textBox40.TabIndex = 0;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(634, 242);
            this.textBox30.Margin = new System.Windows.Forms.Padding(4);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(144, 27);
            this.textBox30.TabIndex = 0;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(309, 293);
            this.textBox39.Margin = new System.Windows.Forms.Padding(4);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(144, 27);
            this.textBox39.TabIndex = 0;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(634, 390);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(144, 27);
            this.textBox33.TabIndex = 0;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(303, 242);
            this.textBox38.Margin = new System.Windows.Forms.Padding(4);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(144, 27);
            this.textBox38.TabIndex = 0;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(634, 341);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(144, 27);
            this.textBox32.TabIndex = 0;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(303, 194);
            this.textBox37.Margin = new System.Windows.Forms.Padding(4);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(144, 27);
            this.textBox37.TabIndex = 0;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(634, 194);
            this.textBox29.Margin = new System.Windows.Forms.Padding(4);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(144, 27);
            this.textBox29.TabIndex = 0;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(309, 144);
            this.textBox36.Margin = new System.Windows.Forms.Padding(4);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(144, 27);
            this.textBox36.TabIndex = 0;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(634, 293);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(144, 27);
            this.textBox31.TabIndex = 0;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(309, 95);
            this.textBox35.Margin = new System.Windows.Forms.Padding(4);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(144, 27);
            this.textBox35.TabIndex = 0;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(634, 144);
            this.textBox28.Margin = new System.Windows.Forms.Padding(4);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(144, 27);
            this.textBox28.TabIndex = 0;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(634, 95);
            this.textBox27.Margin = new System.Windows.Forms.Padding(4);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(144, 27);
            this.textBox27.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1152, 594);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // SaveAs_Cal_button
            // 
            this.SaveAs_Cal_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.SaveAs_Cal_button.Cursor = System.Windows.Forms.Cursors.Default;
            this.SaveAs_Cal_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SaveAs_Cal_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SaveAs_Cal_button.Location = new System.Drawing.Point(741, 690);
            this.SaveAs_Cal_button.Margin = new System.Windows.Forms.Padding(4);
            this.SaveAs_Cal_button.Name = "SaveAs_Cal_button";
            this.SaveAs_Cal_button.Size = new System.Drawing.Size(126, 52);
            this.SaveAs_Cal_button.TabIndex = 46;
            this.SaveAs_Cal_button.Text = "另存为";
            this.SaveAs_Cal_button.UseVisualStyleBackColor = false;
            // 
            // Open_Cal_Button
            // 
            this.Open_Cal_Button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Open_Cal_Button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Open_Cal_Button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Open_Cal_Button.Location = new System.Drawing.Point(566, 690);
            this.Open_Cal_Button.Margin = new System.Windows.Forms.Padding(4);
            this.Open_Cal_Button.Name = "Open_Cal_Button";
            this.Open_Cal_Button.Size = new System.Drawing.Size(126, 52);
            this.Open_Cal_Button.TabIndex = 47;
            this.Open_Cal_Button.Text = "打开";
            this.Open_Cal_Button.UseVisualStyleBackColor = false;
            this.Open_Cal_Button.Visible = false;
            this.Open_Cal_Button.Click += new System.EventHandler(this.Open_Cal_Button_Click);
            // 
            // save_Cal_button
            // 
            this.save_Cal_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.save_Cal_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.save_Cal_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.save_Cal_button.Location = new System.Drawing.Point(386, 690);
            this.save_Cal_button.Margin = new System.Windows.Forms.Padding(4);
            this.save_Cal_button.Name = "save_Cal_button";
            this.save_Cal_button.Size = new System.Drawing.Size(126, 52);
            this.save_Cal_button.TabIndex = 45;
            this.save_Cal_button.Text = "保存";
            this.save_Cal_button.UseVisualStyleBackColor = false;
            this.save_Cal_button.Click += new System.EventHandler(this.save_Cal_button_Click);
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox26.Location = new System.Drawing.Point(867, 7);
            this.textBox26.Margin = new System.Windows.Forms.Padding(4);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(238, 42);
            this.textBox26.TabIndex = 49;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("宋体", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label116.Location = new System.Drawing.Point(752, 7);
            this.label116.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(147, 42);
            this.label116.TabIndex = 48;
            this.label116.Text = "型号：";
            // 
            // Axis_par
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 756);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.label116);
            this.Controls.Add(this.SaveAs_Cal_button);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.save_Cal_button);
            this.Controls.Add(this.Open_Cal_Button);
            this.Font = new System.Drawing.Font("宋体", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Axis_par";
            this.Text = "·";
            this.Load += new System.EventHandler(this.Axis_par_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown34)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown62)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button SaveAs_Cal_button;
        private System.Windows.Forms.Button Open_Cal_Button;
        private System.Windows.Forms.Button save_Cal_button;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.NumericUpDown numericUpDown25;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.NumericUpDown numericUpDown24;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.NumericUpDown numericUpDown23;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.NumericUpDown numericUpDown22;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.NumericUpDown numericUpDown31;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.NumericUpDown numericUpDown30;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.NumericUpDown numericUpDown29;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.NumericUpDown numericUpDown28;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.NumericUpDown numericUpDown27;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown numericUpDown26;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown numericUpDown33;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.NumericUpDown numericUpDown32;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.NumericUpDown numericUpDown34;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.NumericUpDown numericUpDown35;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.NumericUpDown numericUpDown63;
        private System.Windows.Forms.NumericUpDown numericUpDown62;
        private System.Windows.Forms.NumericUpDown numericUpDown61;
        private System.Windows.Forms.NumericUpDown numericUpDown60;
        private System.Windows.Forms.NumericUpDown numericUpDown64;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.NumericUpDown numericUpDown50;
        private System.Windows.Forms.NumericUpDown numericUpDown49;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.NumericUpDown numericUpDown48;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.NumericUpDown numericUpDown47;
        private System.Windows.Forms.NumericUpDown numericUpDown46;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.NumericUpDown numericUpDown51;
        private System.Windows.Forms.NumericUpDown numericUpDown65;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
    }
}