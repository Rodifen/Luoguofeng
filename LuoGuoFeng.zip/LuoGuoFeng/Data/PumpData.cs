﻿using HZH_Controls;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace LuoGuoFeng
{
    interface IPump
    {

    }


    //    // Volumetric piston dispensers – from low viscosity to high viscosity and abrasive，体积式活塞注胶头
    //    // Gear pump dispensers – for continuous dispensing 齿轮泵注胶头
    public class PumpData
    {

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);


        #region Variable

        public PumpData(string Tfilepath)
        {
            filePath = Tfilepath;
        }



        //enum PumpType
        //{
        //    Gear_pump,
        //    Volumetric_piston
        //}

        //enum Axis_Num
        //{
        //    Single,
        //    Doble
        //}

        //enum fashion
        //{
        //    Gear_pump,
        //    Volumetric_piston
        //    // Volumetric piston dispensers – from low viscosity to high viscosity and abrasive，体积式活塞注胶头
        //    // Gear pump dispensers – for continuous dispensing 齿轮泵注胶头
        //}

        private string _PumpType;
        public string PumpType
        {
            get { return _PumpType; }
            set { _PumpType = value; }
        }


        private string _AxisNum;
        public string AxisNum
        {
            get { return _AxisNum; }
            set { _AxisNum = value; }
        }

        private string _fashion;

        public string Fashion
        {
            get { return _fashion; }
            set { _fashion = value; }
        }



        /// <summary>
        /// 减速比
        /// </summary>
        double reduction_ratio;

        /// <summary>
        /// 密度
        /// </summary>
        double density;

        /// <summary>
        /// 泵半径
        /// </summary>
        double radius;

        /// <summary>
        /// 最大行程
        /// </summary>
        double maxStrke = 0;

        /// <summary>
        /// 螺距
        /// </summary>
        double pitch = 0;

        #endregion

        double _Td_Dis = 0;
        bool isReset = false;
   
        double curPos = 0;


        #region interface


        public double Reduction_ratio
        {
            get { return reduction_ratio; }
            set { reduction_ratio = value; }
        }
        public double Density
        {
            get { return density; }
            set { density = value; }
        }
        public double Radius
        {
            get { return radius; }
            set { radius = value; }
        }
        public double MaxStrke
        {
            get { return maxStrke; }
            set { maxStrke = value; }
        }
        public double Pitch
        {
            get { return pitch; }
            set { pitch = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public double BReduction_ratio
        {
            get { return Breduction_ratio; }
            set { Breduction_ratio = value; }
        }
        public double BDensity
        {
            get { return Bdensity; }
            set { Bdensity = value; }
        }
        public double BRadius
        {
            get { return Bradius; }
            set { Bradius = value; }
        }
        public double BMaxStrke
        {
            get { return BmaxStrke; }
            set { BmaxStrke = value; }
        }
        public double BPitch
        {
            get { return Bpitch; }
            set { Bpitch = value; }
        }   
        public double A_Percent
        {
            get { return _A_Percent; }
            set { _A_Percent = value; }
        }
          public double B_Percent
        {
            get { return _B_Percent; }
            set { _B_Percent = value; }
        }


        public double Td_Dis
        {
            get { return _Td_Dis; }
            set { _Td_Dis = value; }
        }
        public bool IsReset
        {
            get { return isReset; }
            set { isReset = value; }
        }

 





        public double CurPosion
        {
            get { return curPos; }
            set { curPos = value; }
        }




        #endregion

        private int _style;

        public int Style
        {
            get { return _style; }
            set { _style = value; }
        }



        string group = String.Empty;
        string filePath;
        private double Breduction_ratio;
        private double Bdensity;
        private double Bradius;
        private double BmaxStrke;
        private double Bpitch;
        private  double _A_Percent;
        private  double _B_Percent;

        //Speed
        private double _speed;
        public double Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
          //Speed
        private double _Bspeed;
        public double BSpeed
        {
            get { return _Bspeed; }
            set { _Bspeed = value; }
        }
        
        private double _TdDis;
        public double TdDis
        {
            get { return _TdDis; }
            set { _TdDis = value; }
        }

         private double _BTdDis;
        public double BTdDis
        {
            get { return _BTdDis; }
            set { _BTdDis = value; }
        }

        private double _quality;

        public double Quality
        {
            get { return _quality; }
            set { _quality = value; }
        }

        private double _time;

        public double Time
        {
            get { return _time; }
            set { _time = value; }
        }
        private bool _Glue;

        public bool Glue
        {
            get { return _Glue; }
            set { _Glue = value; }
        }
        


        public bool Calculation(double quality,double time)
        {
            _quality = quality;
            _time = time;
            if (PumpType == "Gear_pump")   //Gear pump    Volumetric piston
            {
                if (AxisNum == "Single")
                {
                    if (Fashion == "Quality")
                    {
                        CalcSingle( quality,  time);
                        _style = 1;
                    }
                    else if (Fashion == "Time")
                    {
                        CalcSingle(quality, time);
                        _style = 2;
                    }
                }
                else if (AxisNum == "Double")
                {
                    if (Fashion == "Quality")
                    {
                        CalcDouble(quality, time);
                        _style = 3;
                    }
                    else if (Fashion == "Time")
                    {
                        CalcDouble(quality, time);
                        _style = 4;
                    }
                }
                return false;
            }
            else if (PumpType == "Volumetric_piston")
            {
                if (AxisNum == "Single")
                {
                    if (Fashion == "Quality")
                    {
                        CalcSingle(quality, time);
                        _style = 5;
                    }
                    else if (Fashion == "Time")
                    {
                        CalcSingle(quality, time);
                        _style = 6;
                   
                    }
                }
                else if (AxisNum == "Double")
                {
                    if (Fashion == "Quality")
                    {
                        CalcDouble(quality, time);
                        _style = 7;
                    }
                    else if (Fashion == "Time")
                    {
                        CalcDouble(quality, time);
                        _style = 8;
                       
                    }
                }
                return isReset;
            }

            return false;
        }


        /// <summary>
        /// 单泵计算
        /// </summary>
        /// <param name="quality"></param>
        /// <param name="Ttime"></param>
        public void CalcSingle(double quality, double Ttime)
        {
            try
            {
                //0
                double V = quality / density;

                double H = V / (radius * radius * 3.14);

                _TdDis = H * reduction_ratio * pitch;

                _speed = (_TdDis / Ttime) * 1000;
                 var Cur_pos = Global.A.GetPosition();
                 isReset = _TdDis + Cur_pos >= maxStrke;

            }
            catch (Exception ex)
            {
                Global.frmMain.PushMess(ex.ToString());
                Global.frmMain.PushMess("pls check Pump Data parameter!");
            }
        }

       
        /// <summary>
        ///  双泵的计算方法
        /// </summary>
        /// <param name="quality">Q</param>
        /// <param name="time">T</param>
        public bool CalcDouble(double quality, double time)
        {

            var A_quality = quality * (_A_Percent/(_A_Percent+_B_Percent));
            var B_quality = quality * (_B_Percent/(_A_Percent+_B_Percent));

            double V = A_quality / density;

            double H = V / (radius * radius * 3.14);

            _TdDis = H * reduction_ratio * pitch;

            _speed = _TdDis / time * 1000;

            var Cur_Apos = Global.A.GetPosition();
            //B
            double Vb = B_quality / Bdensity;

            double Hb = Vb / (Bradius * Bradius * 3.14);

            _BTdDis = Hb * Breduction_ratio * Bpitch;

            _Bspeed = _BTdDis / time * 1000;
            var Cur_Bpos = Global.B.GetPosition();
            var reA = _TdDis + Cur_Apos >= maxStrke;
            var reB = _TdDis + Cur_Bpos >= BmaxStrke;
            isReset = reA || reB;
            return isReset;

        }



        public void Read()
        {
            _A_Percent = readini("_A_Percent").ToDouble();
            reduction_ratio = readini("reduction_ratio").ToDouble();
            density = readini("density").ToDouble();
            radius = readini("radius").ToDouble();
            maxStrke = readini("maxStrke").ToDouble();
            pitch = readini("pitch").ToDouble();
            AxisNum = readini("AxisNum");
            _PumpType = readini("_PumpType");
            _fashion = readini("_fashion");



            //B
            _B_Percent = readini("_B_Percent").ToDouble();
            Breduction_ratio = readini("Breduction_ratio").ToDouble();
            Bdensity = readini("Bdensity").ToDouble();
            Bradius = readini("Bradius").ToDouble();
            BmaxStrke = readini("BmaxStrke").ToDouble();
            Bpitch = readini("Bpitch").ToDouble();

        }

        public void Write()
        {
            writeini("_A_Percent", _A_Percent.ToString());
            writeini("Reduction_ratio", reduction_ratio.ToString());
            writeini("density", density.ToString());
            writeini("radius", radius.ToString());
            writeini("maxStrke", maxStrke.ToString());
            writeini("pitch", pitch.ToString());
            writeini("AxisNum", AxisNum);
            writeini("_PumpType", _PumpType);
            writeini("_fashion", _fashion);



            //B
            writeini("_B_Percent", _B_Percent.ToString());
            writeini("BReduction_ratio", Breduction_ratio.ToString());
            writeini("Bdensity", Bdensity.ToString());
            writeini("Bradius", Bradius.ToString());
            writeini("BmaxStrke", BmaxStrke.ToString());
            writeini("Bpitch", Bpitch.ToString());
        }

        string readini(string key)
        {
            StringBuilder temp = new StringBuilder();
            GetPrivateProfileString(group, key, "", temp, 255, filePath);
            return temp.ToString();
        }

        /// <summary>
        /// 存储ini
        /// </summary>
        /// <param name="group">数据分组</param>
        /// <param name="key">关键字</param>
        /// <param name="value">关键字对应的值</param>
        /// <param name="filepath">ini文件地址</param>
        void writeini(string key, string value)
        {
            WritePrivateProfileString(group, key, value, filePath);
        }

    }
}
