﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LuoGuoFeng
{
    class CurrentInfo
    {
        public static Authority authority = Authority.Empty;
        public static bool LoginOut = false;
    }
}
