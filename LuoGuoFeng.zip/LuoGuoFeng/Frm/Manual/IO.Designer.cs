﻿namespace LuoGuoFeng
{
    partial class IO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button107 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.lable3 = new System.Windows.Forms.Label();
            this.lable6 = new System.Windows.Forms.Label();
            this.lable2 = new System.Windows.Forms.Label();
            this.lable1 = new System.Windows.Forms.Label();
            this.lable7 = new System.Windows.Forms.Label();
            this.lable5 = new System.Windows.Forms.Label();
            this.lable4 = new System.Windows.Forms.Label();
            this.lable0 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button107
            // 
            this.button107.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button107.Location = new System.Drawing.Point(613, 390);
            this.button107.Margin = new System.Windows.Forms.Padding(2);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(120, 56);
            this.button107.TabIndex = 25;
            this.button107.Text = "Connect";
            this.button107.UseVisualStyleBackColor = true;
            this.button107.Click += new System.EventHandler(this.button107_Click);
            // 
            // button104
            // 
            this.button104.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button104.Location = new System.Drawing.Point(72, 390);
            this.button104.Margin = new System.Windows.Forms.Padding(2);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(120, 56);
            this.button104.TabIndex = 24;
            this.button104.Text = "Press";
            this.button104.UseVisualStyleBackColor = true;
            this.button104.Click += new System.EventHandler(this.button104_Click);
            // 
            // button103
            // 
            this.button103.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button103.Location = new System.Drawing.Point(613, 277);
            this.button103.Margin = new System.Windows.Forms.Padding(2);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(120, 56);
            this.button103.TabIndex = 23;
            this.button103.Text = "Open Door";
            this.button103.UseVisualStyleBackColor = true;
            this.button103.Click += new System.EventHandler(this.button103_Click);
            // 
            // button102
            // 
            this.button102.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button102.Location = new System.Drawing.Point(436, 277);
            this.button102.Margin = new System.Windows.Forms.Padding(2);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(120, 56);
            this.button102.TabIndex = 22;
            this.button102.Text = "Green Lamp";
            this.button102.UseVisualStyleBackColor = true;
            this.button102.Click += new System.EventHandler(this.button102_Click);
            // 
            // button101
            // 
            this.button101.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button101.Location = new System.Drawing.Point(261, 277);
            this.button101.Margin = new System.Windows.Forms.Padding(2);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(120, 56);
            this.button101.TabIndex = 21;
            this.button101.Text = "Yellow Lamp";
            this.button101.UseVisualStyleBackColor = true;
            this.button101.Click += new System.EventHandler(this.button101_Click);
            // 
            // button106
            // 
            this.button106.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button106.Location = new System.Drawing.Point(436, 390);
            this.button106.Margin = new System.Windows.Forms.Padding(2);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(116, 56);
            this.button106.TabIndex = 20;
            this.button106.Text = "Discharger";
            this.button106.UseVisualStyleBackColor = true;
            this.button106.Click += new System.EventHandler(this.button106_Click);
            // 
            // button105
            // 
            this.button105.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button105.Location = new System.Drawing.Point(261, 390);
            this.button105.Margin = new System.Windows.Forms.Padding(2);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(120, 56);
            this.button105.TabIndex = 19;
            this.button105.Text = "Charger";
            this.button105.UseVisualStyleBackColor = true;
            this.button105.Click += new System.EventHandler(this.button105_Click);
            // 
            // button100
            // 
            this.button100.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button100.Location = new System.Drawing.Point(72, 277);
            this.button100.Margin = new System.Windows.Forms.Padding(2);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(120, 56);
            this.button100.TabIndex = 18;
            this.button100.Text = "RED    Lamp";
            this.button100.UseVisualStyleBackColor = true;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // lable3
            // 
            this.lable3.AutoSize = true;
            this.lable3.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable3.Location = new System.Drawing.Point(762, 63);
            this.lable3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable3.Name = "lable3";
            this.lable3.Size = new System.Drawing.Size(31, 21);
            this.lable3.TabIndex = 16;
            this.lable3.Text = "●";
            // 
            // lable6
            // 
            this.lable6.AutoSize = true;
            this.lable6.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable6.Location = new System.Drawing.Point(552, 137);
            this.lable6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable6.Name = "lable6";
            this.lable6.Size = new System.Drawing.Size(31, 21);
            this.lable6.TabIndex = 15;
            this.lable6.Text = "●";
            // 
            // lable2
            // 
            this.lable2.AutoSize = true;
            this.lable2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable2.Location = new System.Drawing.Point(550, 63);
            this.lable2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable2.Name = "lable2";
            this.lable2.Size = new System.Drawing.Size(31, 21);
            this.lable2.TabIndex = 14;
            this.lable2.Text = "●";
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable1.Location = new System.Drawing.Point(340, 63);
            this.lable1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(31, 21);
            this.lable1.TabIndex = 2;
            this.lable1.Text = "●";
            // 
            // lable7
            // 
            this.lable7.AutoSize = true;
            this.lable7.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable7.Location = new System.Drawing.Point(762, 134);
            this.lable7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable7.Name = "lable7";
            this.lable7.Size = new System.Drawing.Size(31, 21);
            this.lable7.TabIndex = 12;
            this.lable7.Text = "●";
            // 
            // lable5
            // 
            this.lable5.AutoSize = true;
            this.lable5.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable5.Location = new System.Drawing.Point(340, 137);
            this.lable5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable5.Name = "lable5";
            this.lable5.Size = new System.Drawing.Size(31, 21);
            this.lable5.TabIndex = 11;
            this.lable5.Text = "●";
            // 
            // lable4
            // 
            this.lable4.AutoSize = true;
            this.lable4.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable4.Location = new System.Drawing.Point(154, 137);
            this.lable4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable4.Name = "lable4";
            this.lable4.Size = new System.Drawing.Size(31, 21);
            this.lable4.TabIndex = 10;
            this.lable4.Text = "●";
            // 
            // lable0
            // 
            this.lable0.AutoSize = true;
            this.lable0.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable0.Location = new System.Drawing.Point(154, 63);
            this.lable0.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lable0.Name = "lable0";
            this.lable0.Size = new System.Drawing.Size(31, 21);
            this.lable0.TabIndex = 9;
            this.lable0.Text = "●";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label103.Location = new System.Drawing.Point(628, 60);
            this.label103.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(109, 26);
            this.label103.TabIndex = 8;
            this.label103.Text = "GlueIn_FD";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label107.Location = new System.Drawing.Point(628, 134);
            this.label107.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(127, 26);
            this.label107.TabIndex = 7;
            this.label107.Text = "GlueOut_FD";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label102.Location = new System.Drawing.Point(438, 60);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(111, 26);
            this.label102.TabIndex = 6;
            this.label102.Text = "GlueIn_BD";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label106.Location = new System.Drawing.Point(435, 134);
            this.label106.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(129, 26);
            this.label106.TabIndex = 5;
            this.label106.Text = "GlueOut_BD";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label101.Location = new System.Drawing.Point(275, 60);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(59, 26);
            this.label101.TabIndex = 4;
            this.label101.Text = "Door";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label105.Location = new System.Drawing.Point(275, 134);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(45, 26);
            this.label105.TabIndex = 3;
            this.label105.Text = "AIR";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label104.Location = new System.Drawing.Point(89, 134);
            this.label104.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(64, 26);
            this.label104.TabIndex = 17;
            this.label104.Text = "Reset";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label100.Location = new System.Drawing.Point(89, 60);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(58, 26);
            this.label100.TabIndex = 13;
            this.label100.Text = "Start";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(653, 194);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(139, 29);
            this.textBox1.TabIndex = 26;
            // 
            // IO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(868, 549);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.lable3);
            this.Controls.Add(this.lable6);
            this.Controls.Add(this.lable2);
            this.Controls.Add(this.lable1);
            this.Controls.Add(this.lable7);
            this.Controls.Add(this.lable5);
            this.Controls.Add(this.lable4);
            this.Controls.Add(this.lable0);
            this.Controls.Add(this.label103);
            this.Controls.Add(this.label107);
            this.Controls.Add(this.label102);
            this.Controls.Add(this.label106);
            this.Controls.Add(this.label101);
            this.Controls.Add(this.label105);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.label100);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "IO";
            this.Text = " ， ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.IO_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Label lable3;
        private System.Windows.Forms.Label lable6;
        private System.Windows.Forms.Label lable2;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label lable7;
        private System.Windows.Forms.Label lable5;
        private System.Windows.Forms.Label lable4;
        private System.Windows.Forms.Label lable0;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox textBox1;
    }
}