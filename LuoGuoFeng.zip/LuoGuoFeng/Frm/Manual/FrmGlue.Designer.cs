﻿namespace LuoGuoFeng
{
    partial class FrmGlue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.len_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.speed_numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDispensing = new System.Windows.Forms.Button();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.B_OGR = new System.Windows.Forms.Button();
            this.A_OGR = new System.Windows.Forms.Button();
            this.Bs_button = new System.Windows.Forms.Button();
            this.Bp_button = new System.Windows.Forms.Button();
            this.As_button = new System.Windows.Forms.Button();
            this.Ap_button = new System.Windows.Forms.Button();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.A_Enable = new System.Windows.Forms.Button();
            this.B_Enable = new System.Windows.Forms.Button();
            this.AllEna = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.len_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.speed_numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            this.SuspendLayout();
            // 
            // len_numericUpDown
            // 
            this.len_numericUpDown.DecimalPlaces = 3;
            this.len_numericUpDown.Location = new System.Drawing.Point(146, 113);
            this.len_numericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.len_numericUpDown.Name = "len_numericUpDown";
            this.len_numericUpDown.Size = new System.Drawing.Size(173, 29);
            this.len_numericUpDown.TabIndex = 16;
            this.len_numericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 3;
            this.numericUpDown4.Location = new System.Drawing.Point(146, 70);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(173, 29);
            this.numericUpDown4.TabIndex = 17;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // speed_numericUpDown1
            // 
            this.speed_numericUpDown1.DecimalPlaces = 2;
            this.speed_numericUpDown1.Location = new System.Drawing.Point(146, 28);
            this.speed_numericUpDown1.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.speed_numericUpDown1.Name = "speed_numericUpDown1";
            this.speed_numericUpDown1.Size = new System.Drawing.Size(173, 29);
            this.speed_numericUpDown1.TabIndex = 18;
            this.speed_numericUpDown1.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(59, 75);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 23);
            this.label8.TabIndex = 13;
            this.label8.Text = "加速度";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(59, 30);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 23);
            this.label20.TabIndex = 14;
            this.label20.Text = "速度";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(59, 119);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 23);
            this.label18.TabIndex = 15;
            this.label18.Text = "距离";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(493, 433);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 49);
            this.button1.TabIndex = 31;
            this.button1.Text = "复位";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDispensing
            // 
            this.btnDispensing.Location = new System.Drawing.Point(230, 433);
            this.btnDispensing.Name = "btnDispensing";
            this.btnDispensing.Size = new System.Drawing.Size(111, 49);
            this.btnDispensing.TabIndex = 32;
            this.btnDispensing.Text = "出胶";
            this.btnDispensing.UseVisualStyleBackColor = true;
            this.btnDispensing.Click += new System.EventHandler(this.btnDispensing_Click);
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.DecimalPlaces = 2;
            this.numericUpDown9.Location = new System.Drawing.Point(492, 350);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(122, 29);
            this.numericUpDown9.TabIndex = 29;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.DecimalPlaces = 2;
            this.numericUpDown7.Location = new System.Drawing.Point(262, 352);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(122, 29);
            this.numericUpDown7.TabIndex = 30;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(429, 352);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 23);
            this.label14.TabIndex = 27;
            this.label14.Text = "时间";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(199, 358);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 23);
            this.label10.TabIndex = 28;
            this.label10.Text = "胶量";
            // 
            // B_OGR
            // 
            this.B_OGR.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.B_OGR.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.B_OGR.ForeColor = System.Drawing.SystemColors.ControlText;
            this.B_OGR.Location = new System.Drawing.Point(433, 281);
            this.B_OGR.Name = "B_OGR";
            this.B_OGR.Size = new System.Drawing.Size(91, 46);
            this.B_OGR.TabIndex = 25;
            this.B_OGR.Text = "B回零";
            this.B_OGR.UseVisualStyleBackColor = false;
            this.B_OGR.Click += new System.EventHandler(this.B_OGR_Click);
            // 
            // A_OGR
            // 
            this.A_OGR.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.A_OGR.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.A_OGR.ForeColor = System.Drawing.SystemColors.ControlText;
            this.A_OGR.Location = new System.Drawing.Point(250, 281);
            this.A_OGR.Name = "A_OGR";
            this.A_OGR.Size = new System.Drawing.Size(91, 46);
            this.A_OGR.TabIndex = 26;
            this.A_OGR.Text = "A回零";
            this.A_OGR.UseVisualStyleBackColor = false;
            this.A_OGR.Click += new System.EventHandler(this.A_OGR_Click);
            // 
            // Bs_button
            // 
            this.Bs_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Bs_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bs_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Bs_button.Location = new System.Drawing.Point(433, 212);
            this.Bs_button.Name = "Bs_button";
            this.Bs_button.Size = new System.Drawing.Size(91, 46);
            this.Bs_button.TabIndex = 33;
            this.Bs_button.Text = "B-";
            this.Bs_button.UseVisualStyleBackColor = false;
            this.Bs_button.Click += new System.EventHandler(this.Bs_button_Click);
            // 
            // Bp_button
            // 
            this.Bp_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Bp_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bp_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Bp_button.Location = new System.Drawing.Point(433, 160);
            this.Bp_button.Name = "Bp_button";
            this.Bp_button.Size = new System.Drawing.Size(91, 46);
            this.Bp_button.TabIndex = 34;
            this.Bp_button.Text = "B+";
            this.Bp_button.UseVisualStyleBackColor = false;
            this.Bp_button.Click += new System.EventHandler(this.Bp_button_Click);
            // 
            // As_button
            // 
            this.As_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.As_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.As_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.As_button.Location = new System.Drawing.Point(250, 212);
            this.As_button.Name = "As_button";
            this.As_button.Size = new System.Drawing.Size(91, 46);
            this.As_button.TabIndex = 35;
            this.As_button.Text = "A-";
            this.As_button.UseVisualStyleBackColor = false;
            this.As_button.Click += new System.EventHandler(this.As_button_Click);
            // 
            // Ap_button
            // 
            this.Ap_button.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.Ap_button.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Ap_button.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Ap_button.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Ap_button.Location = new System.Drawing.Point(250, 160);
            this.Ap_button.Name = "Ap_button";
            this.Ap_button.Size = new System.Drawing.Size(91, 46);
            this.Ap_button.TabIndex = 36;
            this.Ap_button.Text = "A+";
            this.Ap_button.UseVisualStyleBackColor = false;
            this.Ap_button.Click += new System.EventHandler(this.Ap_button_Click);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(74, 160);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(67, 28);
            this.checkBox6.TabIndex = 76;
            this.checkBox6.Text = "定长";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // A_Enable
            // 
            this.A_Enable.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.A_Enable.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.A_Enable.ForeColor = System.Drawing.SystemColors.ControlText;
            this.A_Enable.Location = new System.Drawing.Point(421, 30);
            this.A_Enable.Name = "A_Enable";
            this.A_Enable.Size = new System.Drawing.Size(112, 35);
            this.A_Enable.TabIndex = 77;
            this.A_Enable.Text = "A轴使能";
            this.A_Enable.UseVisualStyleBackColor = false;
            this.A_Enable.Click += new System.EventHandler(this.A_Enable_Click);
            // 
            // B_Enable
            // 
            this.B_Enable.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.B_Enable.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.B_Enable.ForeColor = System.Drawing.SystemColors.ControlText;
            this.B_Enable.Location = new System.Drawing.Point(559, 30);
            this.B_Enable.Name = "B_Enable";
            this.B_Enable.Size = new System.Drawing.Size(112, 35);
            this.B_Enable.TabIndex = 78;
            this.B_Enable.Text = "B轴使能";
            this.B_Enable.UseVisualStyleBackColor = false;
            this.B_Enable.Click += new System.EventHandler(this.B_Enable_Click);
            // 
            // AllEna
            // 
            this.AllEna.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.AllEna.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AllEna.ForeColor = System.Drawing.SystemColors.ControlText;
            this.AllEna.Location = new System.Drawing.Point(481, 75);
            this.AllEna.Name = "AllEna";
            this.AllEna.Size = new System.Drawing.Size(112, 35);
            this.AllEna.TabIndex = 77;
            this.AllEna.Text = "All轴使能";
            this.AllEna.UseVisualStyleBackColor = false;
            this.AllEna.Click += new System.EventHandler(this.AllEna_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 24);
            this.label1.TabIndex = 79;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 24);
            this.label2.TabIndex = 79;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 309);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 24);
            this.label3.TabIndex = 79;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 24);
            this.label4.TabIndex = 79;
            this.label4.Text = "label3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 333);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 24);
            this.label5.TabIndex = 79;
            this.label5.Text = "label5";
            // 
            // FrmGlue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(852, 511);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AllEna);
            this.Controls.Add(this.A_Enable);
            this.Controls.Add(this.B_Enable);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.Bs_button);
            this.Controls.Add(this.Bp_button);
            this.Controls.Add(this.As_button);
            this.Controls.Add(this.Ap_button);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnDispensing);
            this.Controls.Add(this.numericUpDown9);
            this.Controls.Add(this.numericUpDown7);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.B_OGR);
            this.Controls.Add(this.A_OGR);
            this.Controls.Add(this.len_numericUpDown);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.speed_numericUpDown1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmGlue";
            this.Text = "FrmGlue";
            this.Load += new System.EventHandler(this.FrmGlue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.len_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.speed_numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown len_numericUpDown;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown speed_numericUpDown1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnDispensing;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button B_OGR;
        private System.Windows.Forms.Button A_OGR;
        private System.Windows.Forms.Button Bs_button;
        private System.Windows.Forms.Button Bp_button;
        private System.Windows.Forms.Button As_button;
        private System.Windows.Forms.Button Ap_button;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Button A_Enable;
        private System.Windows.Forms.Button B_Enable;
        private System.Windows.Forms.Button AllEna;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}