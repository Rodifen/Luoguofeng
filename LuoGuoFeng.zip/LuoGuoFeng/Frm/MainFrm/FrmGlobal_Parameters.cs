﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LuoGuoFeng
{
    public partial class FrmGlobal_Parameters : Form
    {
        public FrmGlobal_Parameters()
        {
            InitializeComponent();
            openForm(new FrmFlushing());
        }






        private void openForm(Form frm)
        {

            frm.TopLevel = false;
            frm.TopMost = false;
            this.panel1.Controls.Clear();
            this.panel1.Controls.Add(frm);
            frm.Show();

        }

        private void showBar(Button btn)
        {
            this.label1.Location = new Point(btn.Location.X + 208, btn.Location.Y + 18);
        }


        private void btnLoing_Click(object sender, EventArgs e)
        {
            openForm(new FrmFlushing());
            showBar(btnFlushing);
        }

        private void btnFlushing_Click(object sender, EventArgs e)
        {
            openForm(new FrmFlushing());
            showBar(btnFlushing);
        }

        private void btnPriming_Click(object sender, EventArgs e)
        {
            openForm(new FrmPriming());
            showBar(btnPriming);
        }

        private void btnThaching_Click(object sender, EventArgs e)
        {
            openForm(new Teaching());
            showBar(btnThaching);
        }

        private void btnWeight_Click(object sender, EventArgs e)
        {
            openForm(new FrmWeight());
            showBar(btnWeight);
        }

        private void btnNeedle_Click(object sender, EventArgs e)
        {
            openForm(new FrmNeedle());
            showBar(btnNeedle);
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            openForm(new Settings());
            showBar(btnSetting  );
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
